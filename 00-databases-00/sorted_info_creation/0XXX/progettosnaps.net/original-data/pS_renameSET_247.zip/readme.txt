RENAMESET.DAT/INI 0.247
=======================
(C) progetto-SNAPS 2009/2022 AntoPISA

renameSET.dat:    0.247
Internal version:  4.92

The package contains:

- allMAMEremoved.txt      : List with all machines/BIOS/devices removed from MAME.
- allMAMErenamed.txt      : List with all machines/BIOS/devices renamed in MAME.
- allMAMEset.txt          : List with all the machines/BIOS/devices added to MAME from the first version; each machine has a unique progressive number.
- renameSET.dat           : All data and counts relating to each published MAME, including renamed and deleted machines.
- renameSET.ini           : Like the previous file but in another format, which can be used with the "MAMErenSET" tool to automate updating operations of resources.
- renameSET_245-246.ini   : Like "renameSET.ini" but only includes the last two releases of the MAME.
- renameSET_SL.dat        : Like "renameSET.dat" but related to software lists.
- HBMAME\renameSET_HB.dat : Like "renameSET.dat" but related to the derived HBMAME emulator.
- HBMAME\renameSET_HB.ini : Like the previous file but in another format, which can be used with the "MAMErenSET" tool to automate updating operations.

====================================================================================================================================================================

How to read "renameSET.dat"

For each version of MAME released, are provided, in order:

Line 1 : Official version and [progressive numbering].
Line 2 : Release date (yyyy/mm/dd).
Line 3 : Summary of the counts (with any differences highlighted -/+):

         Items - The total number of all elements that make up MAME: machines, devices and BIOSes;
         Machines - Counting of all machines (Parents + Clones) (*);
         Parents - Counting of all "Parent" machines (including BIOS but excluding Devices) (*);
         Clones - Counting of all "Clones" machines (always excluding Devices) (*);
         BIOS - Counting of all "BIOS" (*);
         Devices - Counting of all "Devices".
         use CHDs - Counting of machines and BIOS using CHDs (*);
         use Samples - Counting of machines using Samples (Device not counted); 
         Working - Counting of all "Working" machines (*);
         Not Working - Counting of "Non Working" machines (*);
         Mechanical - Counting of "Mechanical" machines (*);
         Not Mechanical - Counting of non "Mechanical" machines (*);
         SaveState Supported - Count of machines that support "SaveState" (*);
         SaveState Not Supported - Count of machines that do not support the "SaveState" (*);
         Horizontal - Counting of machines that have a horizontal screen (*);
         Vertical - Counting of machines that have a vertical screen (*).

        (*): Data detected by the official MAME.

Line 4 : Summary of the counts (with any differences highlighted -/+) about:

         roms - Counting of all roms (including CHDs and BIOS);
         program roms - Counting of roms belonging to machines or devices;
         BIOS roms - Count of roms belonging to the BIOS;
         CHD roms - Counting of all CHDs;
         sample roms - Counting of all samples.

Line 5 : Summary of the software lists and related software included:

         active SL - Count of all active Software Lists (there are in fact some present in the "hash" folder but not yet detected by MAME);
         orphan SL - Counting of Software Lists currently unsupported;
         active software - Counting of all supported software titles;
         orphan software - Count of all software titles surveyed but not yet supported.

         The complete summary with all data is available in the file "renameSET_SL.dat".

Line 6 : List of renamed machines/devices.

         List of all machines or devices renamed between the new version and the previous one. The format is as follows:
         
         OldName > NewName

Line 7 : List of removed machines/devices.

         List of all machines or devices removed from MAME between the new version and the previous one.



Home-page: https://www.progettosnaps.net/renameset/

(C) 2009/2022 AntoPISA