﻿progetto-SNAPS © 2009/2021 AntoPISA

renameSET.dat 0.237
Internal version: 4.73

The package contains:

- allMAMEremoved.txt   : List with all machines/BIOS/devices removed from MAME.
- allMAMErenamed.txt   : List with all machines/BIOS/devices renamed in MAME.
- allMAMEset.txt       : List with all the machines/BIOS/devices added to MAME from the first version; each machine has a unique progressive number.
- renameSET.dat        : All data and counts relating to each published MAME, including renamed and deleted machines.
- renameSET.ini        : Like the previous file but in another format, which can be used with the "MAMErenSET" tool to automate updating operations of resources.
- renameSET_236-237.ini: Like "renameSET.ini" but only includes the last two releases of the MAME.
- renameSET_HB.dat     : Like "renameSET.dat" but related to the derived HBMAME emulator.
- renameSET_HB.ini     : Like the previous file but in another format, which can be used with the "MAMErenSET" tool to automate updating operations.
- renameSET_SL.dat     : Like "renameSET.dat" but related to software lists.


Home-page: https://www.progettosnaps.net/renameset/