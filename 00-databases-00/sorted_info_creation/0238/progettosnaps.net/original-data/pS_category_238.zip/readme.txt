MAME CATEGORY.ini 0.238  (Nov 27, 2021)
(C) AntoPISA      www.progettoSNAPS.net
---------------------------------------

readme:
=======
In this package you can find these ini files:

- Arcade: List with arcade machines in MAME.
- Arcade_BIOS: List with arcade BIOSes only.
- Arcade_NOBIOS: List with arcade machines in MAME (BIOS excluded).
- Bootlegs: List of 'Bootleg' machines.
- Cabinets: MAME machines divided by type of cabinets (only arcade - by b4nd1t0).
- Category: MAME machines divided by category.
- CHD (no BIOS): List all the machines that need a CHD to run (BIOS excluded).
- CHD (Working): List all the machines working that need a CHD to run (BIOS excluded).
- Driver: MAME machines divided by drivers.
- FreePlay: MAME machines with free-play option (only arcade - by b4nd1t0).
- Mechanical Arcade: List of mechanical arcade machines (to complete MAMEUI).
- mess: List with all others machines in MAME.
- MonoChrome: MAME machines divided by colors.
- Non Bootlegs: List the machines excluding all 'bootlegs'.
- Non Mechanical Arcade: List of not mechanical arcade machines (to complete MAMEUI).
- Not Working Arcade: List of not working arcade machines (to complete MAMEUI).
- Parents Arcade: List of arcade parent machines (to complete MAMEUI).
- Players: List of MAME arcade machines divided by number of players.
- Resolution: MAME machines divided by original resolution.
- Screenless: Only MAME machines without screen.
- Working Arcade: List of working arcade machines (to complete MAMEUI).
- Working Arcade Clean: List all the working machines excluding: Casino, Electromechanical, Medal Game, Quiz, Slot Machine, Whac-A-Mole, Tabletop (Mahjong, Othello, Pachino, etc.) and Utilities.

These files must be copied to the directory called "folders" of your MAME.

whatsnew:
=========
2021/11/27: Aligned files to MAME 0.238.
2021/11/20: Download link moved to "Support Files" page; changed a filename: from "Originals Arcade.ini" to "Parents Arcade.ini".
2021/10/31: Aligned files to MAME 0.237.
2021/10/03: Aligned files to MAME 0.236.
2021/08/30: Aligned files to MAME 0.235.
2021/08/05: Added "CHD.ini" and "CHD_Working.ini" to the package.
2021/08/02: Aligned files to MAME 0.234.
2021/07/06: Aligned files to MAME 0.233.
2021/06/01: Aligned files to MAME 0.232.
2021/05/02: Aligned files to MAME 0.231.
2021/04/17: Fixed some files (eliminated the presence of BOMs that created problems). Thanks to Saknet and Robbbert.
2021/04/05: Aligned files to MAME 0.230.
2021/02/27: Aligned files to MAME 0.229.
2021/02/05: Aligned files to MAME 0.228.
2021/01/13: Aligned files to MAME 0.227.
2020/11/01: Aligned files to MAME 0.226.
2020/10/05: Aligned files to MAME 0.225.
2020/09/01: Aligned files to MAME 0.224.
2020/08/24: Aligned files to MAME 0.223.
2020/07/14: Aligned files to MAME 0.222.
2020/05/20: Aligned files to MAME 0.221.
2020/04/30: Completely revised the "Plug n 'Play TV Game" category, adding sub-classes (such as "Action", "Casino"," Sport ", etc).
2020/04/07: Aligned files to MAME 0.220.
2020/03/09: The "arcade_BIOS.ini", "arcade_NOBIOS.ini", "arcade.ini" and "mess.ini" files have been moved here from the "vrrsion" package.
2020/03/02: Aligned files to MAME 0.219.
2020/02/05: Aligned files to MAME 0.218.
2019/12/27: Aligned files to MAME 0.217.
2019/11/30: Aligned files to MAME 0.216.
2019/11/01: Aligned files to MAME 0.215.
2019/09/28: Aligned files to MAME 0.214.
2019/09/14: Added the "Working_Arcade_Clean.ini" file.
2019/09/08: Aligned files to MAME 0.213.
2019/08/25: Added the "Bootleg.ini" and "Non Bootlegs.ini" files.
2019/08/05: Aligned files to MAME 0.212.
2019/07/06: Aligned files to MAME 0.211.
2019/06/30: Fixed a dozen incorrect assignments weren't assigned to the 0.34b5 and 0.35b6 versions.
2019/06/06: Aligned files to MAME 0.210.
2019/04/27: Aligned files to MAME 0.209.
2019/03/30: Aligned files to MAME 0.208.
2019/02/28: Aligned files to MAME 0.207.
2019/02/02: Aligned files to MAME 0.206.
2018/12/27: Aligned files to MAME 0.205.
2018/11/29: Aligned files to MAME 0.204.
2018/11/24: Added'Omega Race' to monochrome.ini (thanks to Mr Ric).
2018/11/02: Aligned files to MAME 0.203.
2018/09/28: Aligned files to MAME 0.202.
2018/08/31: Aligned files to MAME 0.201.
2018/07/27: Aligned files to MAME 0.200.
2018/06/29: Aligned files to MAME 0.199.
2018/05/31: Aligned files to MAME 0.198.
2018/05/29: Changed Category for "Michael Jackson's Moonwalker" series, from "Maze/Fighter" to "Platform/Fighter Scrolling" (thanks to Chris Mouland).
2018/05/04: Changed the genre of "Electromechanical / Reels" machines in "Slot Machine / Reels" and "Casino / Reels" in "Slot Machine / Video Slot".
2018/04/27: Aligned files to MAME 0.197.
2018/03/31: Aligned files to MAME 0.196.
2018/03/15: Fixed the categories of many "Mahjong" games instead of the more correct "Hanafuda".
2018/03/01: Aligned files to MAME 0.195.
2018/02/02: Aligned files to MAME 0.194.
2017/12/28: Aligned files to MAME 0.193.
2017/11/30: Aligned files to MAME 0.192.
2017/10/28: Aligned files to MAME 0.191.
2017/10/20: Change category 'Othello' in 'Othello - Reversi' and fixed category of 1,250 machines.
2017/09/28: Aligned files to MAME 0.190.
2017/09/03: Aligned files to MAME 0.189.
2017/08/18: The entire file is revised and corrected.
2017/08/07: Added these ini files (useful especially for completing the MAMEUI filters): "Clones Arcade.ini", "Mechanicals Arcade.ini", "Non Mechanicals Arcade.ini", "Not Working Arcade.ini", "Originals Arcade.ini" and  "Working_arcade.ini".
2017/07/28: Aligned files to MAME 0.188.
2017/07/03: Fixed resolution.ini and screenless.ini.
2017/06/29: Aligned files to MAME 0.187.
2017/06/25: Added "mature" sub-category to: smissw (thanks to caipora) and seljan2.
2017/06/05: Delete the machines with a vector display mistakenly added to the "screenless.ini" file.
2017/06/03: Aligned files to MAME 0.186.
2017/04/28: Aligned files to MAME 0.185.
2017/04/17: Added to the package: "monochrome.ini", "resolution.ini" and "screenless.ini" that until now, had file own. Rewrited the readme file.
2017/04/06: Added to the package 2 new ini files: "cabinets.ini" and "freeplay.ini", designed and edited by b4nd1t0.
2017/04/02: Aligned files to MAME 0.184.
2017/03/29: Added "driver.ini" file that lists the MAME machines divided by drivers.
2017/02/25: Aligned file to MAME 0.183.
2017/01/27: Aligned file to MAME 0.182.
2016/12/30: Aligned file to MAME 0.181.
2016/12/04: Aligned file to MAME 0.180.
2016/10/27: Aligned file to MAME 0.179.
2016/10/20: Fixed entry (cnfball) "Handheld Game Console" to "Handheld Game".
2016/09/30: Aligned file to MAME 0.178.
2016/09/04: Aligned file to MAME 0.177. From this version it is helped by a tool for the creation and verification of the .ini files created by motoschifo.
2016/07/31: Aligned to MAME 0.176.
2016/07/04: Aligned to MAME 0.175.
2016/05/30: Aligned to MAME 0.174.
2016/05/01: Aligned to MAME 0.173.
2016/04/01: Aligned to MAME 0.172.
2016/02/26: Aligned to MAME 0.171.
2016/02/24: Removed (category_home.ini) file and renamed (category_full.ini) to (category.ini). Removed also the category 'Arcade, Fruit Machine, Pinball' and added all the arcade games categories from catver file.
2016/02/01: Some category changes suggested by Pernod (abc110, abc310, acw443, reutapm, torchf, torchh10 and torchh21).
2016/01/29: Aligned to MAME 0.170.
2016/01/01: Aligned to MAME 0.169.
2015/11/26: Aligned to MAME 0.168.
2015/10/29: Aligned to MAME 0.167.
2015/10/05: Fixed typo error.
2015/10/02: Aligned to MAME 0.166.
2015/08/28: Aligned to MAME 0.165.
2015/07/30: Aligned to MAME 0.164.
2015/06/25: Aligned to MAME 0.163.
2015/05/30: Aligned to MAME 0.162 (from this version 2 files: full and home only. The full version now it shows only two the categories 'Arcade Game' and 'Arcade BIOS').
2015/04/30: Aligned to MAME 0.161.
2015/04/28: Added 'Astrological Computer', 'Educational Game' and 'Electronic Game' categories.
2015/02/25: Aligned to MAME 0.160.
2015/02/28: Delete 'Unsorted' category; all machine are sorted.
2015/02/25: Aligned to MAME 0.159.
2015/02/07: First release of the files in this mode.
2015/02/05: Complete overhaul of the old file (renaming, adding and checking items).


(C) 2015/2021 AntoPISA